

<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>php crud oparation</title>
	<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
</head>
<body>

<div class="row">
	<div class="col-md-6 offset-md-3">
		 <h1>Registration Form</h1>
    <form action="register.php" method="post">
    	<div class="form-group">
      <label for="first-name">First Name:</label>
      <input class="form-control" type="text" id="first-name" name="first-name" required><br><br>
      </div>

      <div class="form-group">
      <label for="last-name">Last Name:</label>
      <input class="form-control" type="text" id="last-name" name="last-name" required><br><br>
      </div>
      <div class="form-group">
      <label for="email">Email Address:</label>
      <input class="form-control" type="email" id="email" name="email" required><br><br>
      </div>

      <div class="form-group">
      <label for="password">Password:</label>
      <input class="form-control" type="password" id="password" name="password" required><br><br>
      </div>

      <div class="form-group">
      <label for="confirm-password">Confirm Password:</label>
      <input class="form-control" type="password" id="confirm-password" name="confirm-password" required><br><br>
      </div>
      <button name="save" class="form-control btn btn-info mt-3">Register</button>
    </form>

	</div>
</div>














<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js"></script>
</body>
</html>