<!DOCTYPE html>
<html>
<head>
	<title>Login Form</title>
</head>
<body>
	<h1>Login Form</h1>
	<form action="welcome.php" method="post">
		<label for="email">Email address:</label><br>
		<input type="email" id="email" name="email" required><br>

		<label for="password">Password:</label><br>
		<input type="password" id="password" name="password" required><br>

		<input type="submit" value="save">
	</form>
	
	
</body>
</html>